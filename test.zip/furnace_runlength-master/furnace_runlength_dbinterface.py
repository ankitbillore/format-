"""
File                : furnace_runlength_dbinterface.py

Description         : This file contains DB interface class. This class contains
                      methods that are used to fetch input data for Furnace Runlength
                      Algorithm from DB and to store the resultant data which is the
                      outcome of the Furnace Runlength Algorithm into DB

Author              : LNS Team

Date Created        : 27-Nov-2019

Date Last modified  :

Copyright (C) 2019 LivNSense Technologies - All Rights Reserved

"""

import psycopg2,sys,os
from psycopg2.extras import execute_values
import time as t
import numpy as np
import json
import pandas as pd

from cassandra.cluster import Cluster
from cassandra.query import BatchStatement
from ssl import SSLContext, PROTOCOL_TLSv1

from furnace_runlength_config import USER, PASSWORD, HOST, PORT, DATABASE, SCHEMA, TABLE_NAME, logger

from furnace_runlength_config import CERTFILE_FILE_PATH, KEYFILE_FILE_PATH
from furnace_runlength_config import DATABASEIP, KEYSPACE,ONE_DAY_EPOCH,CONFIG_KEYSPACE
from furnace_runlength_config import RESULT_TABLE_NAME, ERROR_DETAILS_TABLE

# Config files Path

from furnace_runlength_config import BASIC_CONFIG_FILE_PATH, CONFIG_FILE_PATH, ERROR_CODE_FILE_PATH,TAG_LIST_FILE_PATH
from furnace_runlength_config import TAG_MIN_MAX_FILE_PATH, FURNACE_DOL_MAPPING_FILE_PATH, GOOD_FURNACE_DATA_FILE_PATH
from furnace_runlength_config import OUTPUT_TAG_DESCRIPTION_FILE_PATH,CONFIG_FOLDER_NAME,CSV_FOLDER_NAME
from furnace_runlength_config import CONFIG_TABLE_NAME,ALGORITHM_NAME,CONFIG_PARAMETERS_FILE_PATH

# Below Parameters need to be moved once it is integrated with DB
COUNT=0
class FurnaceRunlengthDBInterface(object):
    '''
    Furnace Runlength Algorithm's  DB interface class
    '''

    def connect_cassandra(self):
        global COUNT

        """
        This function will connect to cassandra database and all required
        connection details will be taken from config.py file
        """
        session=None
        cluster=None
        try:
            COUNT += 1
            ssl_context = SSLContext(PROTOCOL_TLSv1)

            ssl_context.load_cert_chain(
                certfile=CERTFILE_FILE_PATH,
                keyfile=KEYFILE_FILE_PATH)
            cluster = Cluster(DATABASEIP, ssl_context=ssl_context,connect_timeout=10.0 )
            session = cluster.connect(KEYSPACE)
            session.default_timeout = 300

            print("cassandra database is connected")
            logger.info("cassandra database is connected")

            return session,cluster

        except Exception as ex:
            t.sleep(2)
            exc_type, exc_obj, exc_tb = sys.exc_info()

            print(exc_type, exc_tb.tb_lineno)
            if COUNT < 5:
                self.connect_cassandra()

            logger.error('Failed to connect Cassandra DB  : ' + str(ex))
            return session,cluster
    def config_check(self):

        cluster= None
        configuration_df=pd.DataFrame()
        try:

            select_query = "SELECT algorithm_name,file_param_name,flag,blobAsText(file_content) as file_content,param_value,type  from {}.{} WHERE " \
                           "algorithm_name = '{}' and flag=1 ALLOW FILTERING;".format(CONFIG_KEYSPACE,CONFIG_TABLE_NAME,
                                                                                     ALGORITHM_NAME)
            session, cluster = self.connect_cassandra()
            latest_df = session.execute(select_query)
            configuration_df = pd.DataFrame(latest_df)
            # dff=pd.DataFrame(latest_df)
            if not configuration_df.empty:

                param_df=configuration_df[configuration_df['type']==1]
                config_files_df=configuration_df[configuration_df['type']==2]
                batch = BatchStatement()
                insert_user = session.prepare("INSERT INTO {}.{} (algorithm_name, file_param_name,flag) VALUES (?,?,?)".format(KEYSPACE,CONFIG_TABLE_NAME))
                if not param_df.empty:
                    param_list=list(param_df['file_param_name'])
                    param_df=param_df.set_index('file_param_name')
                    config_param_df=pd.read_csv(CONFIG_PARAMETERS_FILE_PATH).set_index('Parameter')

                    for param in param_list:
                        config_param_df.loc[param, 'Value']=param_df.loc[param,'param_value']
                        batch.add(insert_user,(ALGORITHM_NAME,param,0))
                    config_param_df.to_csv(CONFIG_PARAMETERS_FILE_PATH)
                if not config_files_df.empty:
                    for row in config_files_df.itertuples():
                        df_json = json.loads(row[4])
                        df = pd.DataFrame.from_dict(df_json)
                        filename=CONFIG_FOLDER_NAME+os.sep+ CSV_FOLDER_NAME+os.sep+row[2]
                        df.to_csv(filename,index=False)
                        batch.add(insert_user,(ALGORITHM_NAME,row[2],0))
                session.execute(batch)
                logger.info('Config files has been changed and new files are updated into local files')
        except Exception as ex:
            print(ex)
            logger.error("Error while updating the config files %s",ex)

        finally:
            if cluster:
                cluster.shutdown()

    def readConfigParametersFromDB(self):
        '''
        This method is used to fetch configuration file details from DB

        Input Parameters:  None
        Returns: Return data frames for basic_config_df,config_df, error_code_df,
         furnace_dol_mapping_df, good_furnace_data_df, tag_min_max_df

        '''
        basic_config_df = pd.DataFrame()
        config_df = pd.DataFrame()
        error_code_df = pd.DataFrame()
        furnace_dol_mapping_df = pd.DataFrame()
        good_furnace_data_df = pd.DataFrame()
        tag_min_max_df = pd.DataFrame()
        self.tag_list_df = pd.DataFrame()
        output_tag_description_df = pd.DataFrame()
        try:

            basic_config_df = pd.read_csv(BASIC_CONFIG_FILE_PATH)
            config_df = pd.read_csv(CONFIG_FILE_PATH)
            error_code_df = pd.read_csv(ERROR_CODE_FILE_PATH)
            furnace_dol_mapping_df = pd.read_csv(FURNACE_DOL_MAPPING_FILE_PATH)
            good_furnace_data_df = pd.read_csv(GOOD_FURNACE_DATA_FILE_PATH)
            tag_min_max_df = pd.read_csv(TAG_MIN_MAX_FILE_PATH)
            self.tag_list_df = pd.read_csv(TAG_LIST_FILE_PATH)
            output_tag_description_df = pd.read_csv(OUTPUT_TAG_DESCRIPTION_FILE_PATH)
            return basic_config_df,config_df, error_code_df, furnace_dol_mapping_df, good_furnace_data_df \
                ,tag_min_max_df,self.tag_list_df,output_tag_description_df

        except Exception as ex:

            logger.error("Exception occurred while Fetching Config Data from \
                          Cassandra database for Furnace Runlength : " + str(ex))

            return basic_config_df,config_df, error_code_df, furnace_dol_mapping_df, good_furnace_data_df,\
                   tag_min_max_df,self.tag_list_df,output_tag_description_df

    def readDolInputFromDB(self,curr_time):
        '''
        This method is used to fetch Furnace Runlength algorithm's
                dol values of tags from DB
        :param timestamp: timestamp to fetch the tag values
        :return: returns dataframe which contains value of DOL tags.
        '''
        cluster = None
        input_dol_df = pd.DataFrame()
        try:

            df = self.tag_list_df
            tag_list = tuple(df['dol_tag_name'].dropna())
            session,cluster = self.connect_cassandra()

            latest_one_day =curr_time-ONE_DAY_EPOCH #one day epoch contains the
            #time_list=tuple(range(latest_one_day,curr_time,360000))
            latest_data = session.execute(
                "select tag_name as dol_tag_name, input_time,avg(tag_value) as input_values from {}.{} where tag_name in {} and input_time >{} and input_time <={} group by tag_name;".format(
                    KEYSPACE,TABLE_NAME, tag_list,latest_one_day,curr_time))
            input_dol_df = pd.DataFrame(latest_data)
            if not input_dol_df.empty:

                input_dol_df['TimeStamp'] = pd.to_datetime(input_dol_df['input_time'], unit='ms')
                input_dol_df = pd.merge(df['dol_tag_name'], input_dol_df[['dol_tag_name', 'input_values', 'TimeStamp']],
                                          on='dol_tag_name', how='left')

                input_dol_df = pd.pivot_table(input_dol_df, index='TimeStamp', columns='dol_tag_name',
                                                values='input_values').reset_index()
            return input_dol_df

        except Exception as ex:
            exc_type, exc_obj, exc_tb = sys.exc_info()

            #print(exc_type, exc_tb.tb_lineno)
            logger.error("Exception occurred while Fetching Data from Cassandra database  : " + exc_type, exc_tb.tb_lineno,str(ex))

            return input_dol_df
        finally:
            if cluster:
                cluster.shutdown()

    def readInputDataFromDB(self,dol_df,tag_list_df,curr_time):
        '''
        This method is used to fetch Furnace Runlength algorithm's
        average values and standard deviation values of tags from DB
        :param dol_df: this dataframe contains the dol max value to calculate how many days data need to be fetched for input
        :param tag_list_df: contains list of tags whose values need to be fetched from database
        :return: returns input data
        '''

        input_data_df = pd.DataFrame()
        cluster = None
        try:
            #curr_time = t.time()
            #curr_time = int((curr_time - (curr_time % 60) - 120) * 1000) #some tags updating with the delay of 2 minutes hence 120 need to be subracted

            dol_max_value = max(dol_df['DOL_Value'])
            df = tag_list_df
            max_dol_time= curr_time-(dol_max_value*ONE_DAY_EPOCH)
            tag_list = tuple(df['tag_name'])
            time_list = list(range(max_dol_time,curr_time+1,ONE_DAY_EPOCH))

            session,cluster = self.connect_cassandra()
            for i in range(0,dol_max_value):
                latest_data = session.execute(
                    "select tag_name as tag_name, input_time,avg(tag_value) as input_values from {}.{} where tag_name in {} and input_time >{} and input_time <={} group by tag_name;".format(
                    KEYSPACE,TABLE_NAME, tag_list,time_list[i],time_list[i+1]))
                latest_data_df= pd.DataFrame(latest_data)
                latest_data_df['TimeStamp'] = pd.to_datetime(time_list[i+1],unit='ms')
                input_data_df=input_data_df.append(latest_data_df,sort=False)
            if not input_data_df.empty:
                logger.info("data is fetched")
                input_data_df = input_data_df[['tag_name', 'input_values','TimeStamp']]
                #input_data_df['TimeStamp'] = pd.to_datetime(input_data_df['input_time'], unit='ms')
                input_data_df = pd.merge(df['tag_name'], input_data_df[['tag_name', 'input_values', 'TimeStamp']],
                                          on='tag_name', how='left')

                input_data_df = pd.pivot_table(input_data_df, index='TimeStamp', columns='tag_name',
                                                values='input_values',dropna=False).reset_index()
            return input_data_df
        except Exception as ex:
            print(ex)
            logger.error("Exception occurred while Fetching Data from Cassandra database  : " + str(ex))

            return input_data_df
        finally:
            if cluster:
                cluster.shutdown()

    def updateResultDataIntoDB(self, result_data):
        '''
        This method is used to update the Furnace Runlength Algorithm
        result of into DB table

        Input Parameters   :
            1.  result_data  - This parameter holds the result of all furnaces

        Returns:   None

        '''
        connection = None
        cursor = None
        try:
            connection = psycopg2.connect(user=USER,
                                          password=PASSWORD,
                                          host=HOST,
                                          port=PORT,
                                          database=DATABASE)
            cursor = connection.cursor()
            logger.info('psycopg connection successful')

            #print(result_data)
            '''
            data contains for each furnace :
            ( Console_name,equipment_tag,algo_tag,tag_name,actual_value,
            predicted_value,alert_flag,description,unit,timestamp)
            '''
            postgres_insert_query = """ INSERT INTO {}.{} (console_name,equipment_tag,coil, actual_dol, predicted_dol,\
                                               predicted_coil_dol,description,timestamp,algo_tag,alert_flag,coil_alert_flag,concern)\
                                                VALUES %s""".format(SCHEMA,RESULT_TABLE_NAME)
            psycopg2.extras.execute_values(cursor, postgres_insert_query, result_data)
            connection.commit()
            #print(cursor.rowcount)
            logger.info("Updated Furnace Runlength Algorithm result values into a table ")

        except (Exception, psycopg2.Error) as ex:
            logger.error("Error occurred while updating the result of Furnace \
                          Runlength algorithm  into DB : " + str(ex))

        finally:
            # closing database connection.
            if (connection):
                cursor.close()
                connection.close()
                logger.info('psycopg connection closed')

    def updateErrorDetailsIntoDB(self, error_result_data):
        '''
        This method is used to insert the error details like offline,data stuck
        of the Furnace Runlength algorithm into DB table

        Input Parameters   :
            1.  error_result_data  - This parameter holds the tags and error code
            details of Furnace Runlength algorithm

        Returns:   None

        '''
        #print(error_result_data)
        connection = None
        cursor = None
        try:
            connection = psycopg2.connect(user=USER,
                                          password=PASSWORD,
                                          host=HOST,
                                          port=PORT,
                                          database=DATABASE)
            cursor = connection.cursor()
            logger.info('psycopg connection successful')
            #print(error_result_data)

            '''
            data contains tags details for each furnace
            ( console_name, equipment_tag,equipment_part,algo_tag, tag_name,error_code, timestamp )
            '''
            postgres_insert_query = """INSERT into {}.{} (console_name,equipment_tag,algo_tag,tag_name \
                                        ,error_code,timestamp ) VALUES %s""".format(SCHEMA,ERROR_DETAILS_TABLE)
            psycopg2.extras.execute_values(cursor, postgres_insert_query, error_result_data)
            connection.commit()
            #print(cursor.rowcount)
            logger.info("Updated Furnace Runlength algorithm's error values into a table ")

        except Exception as error:
            logger.error("Error occurred while updating error code details of \
                          Furnace Runlength algorithm into DB : " + str(error))

        finally:
            # closing database connection.
            if (connection):
                cursor.close()
                connection.close()
                logger.info('psycopg connection closed')
