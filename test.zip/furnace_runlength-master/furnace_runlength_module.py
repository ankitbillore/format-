"""
File                : furnace_runlength_module.py

Description         : This file contains the starting method for Furnace Runlength Algorithm. When this module is started,
                      it schedules the algorithm to run once in every
                      configured interval

Author              : LNS Team

Date Created        : 27-Nov-2019

Date Last modified  :

Copyright (C) 2019 LivNSense Technologies - All Rights Reserved

"""
import schedule
import time,pandas as pd

from furnace_runlength_config import logger,CONFIG_PARAMETERS_FILE_PATH

from furnace_runlength_calculation import furnace_runlength_module

'''
Scheduler class definition
'''

if __name__ == "__main__":

    # Starting point of Furnace Runlength Algorithm Module

    try:
        '''
        Create a scheduler object and schedule Furnace Runlength
        Algorithm  to run at every  configured Interval 
        '''
        while True:

            config_df = pd.read_csv(CONFIG_PARAMETERS_FILE_PATH)
            config_df = config_df.set_index('Parameter')
            SCH_INT = config_df.loc['scheduling_interval', 'Value']
            for minute in range(2, 60, SCH_INT):
                val = ":{minute:02d}".format(minute=minute)
                schedule.every().hours.at(val).do(furnace_runlength_module)
            while True:
                config_df = pd.read_csv(CONFIG_PARAMETERS_FILE_PATH)
                config_df = config_df.set_index('Parameter')
                SCHEDULE_INT = config_df.loc['scheduling_interval', 'Value']
                if not (SCH_INT == SCHEDULE_INT):
                    schedule.clear()
                    break
                schedule.run_pending()
                time.sleep(60)

    except Exception as ex:
        print(ex)
        # print("Failed to schedule a Furnace Runlength Algorithm for \
        #      module event ...,"+ str(ex))
        logger.info("Failed to schedule a Furnace Runlength Algorithm module event ...," + str(ex))



