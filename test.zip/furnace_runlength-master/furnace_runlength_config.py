"""
File                : furnace_runlength_config.py

Description         : This file contains all configuration parameters details,
                      constant parameter details and input files path information
                      that are used in Furnace Run length algorithm

Author              : LNS Team

Date Created        : 27-Nov-2019

Date Last modified  :

Copyright (C) 2019 LivNSense Technologies - All Rights Reserved

"""
from configparser import ConfigParser
import os

import logging
from logging.handlers import RotatingFileHandler

# import the settings file path from docker environment
setting_file = os.environ['settings']

# create config parser obj
config = ConfigParser()

# reading the properties file
config.read(setting_file)

# evaluating the environment is development or production
ENV = os.environ['env']

_env = 'PROD'
if ENV == 'PROD':
    _env = 'PROD_'
if ENV == 'DEV':
    _env = 'DEV_'
print(_env)

POSTGRES_SECTION = '{}POSTGRES'.format(_env)
CASSANDRA_SECTION = '{}CASSANDRA'.format(_env)
LOGGING_SECTION = '{}LOGGING'.format(_env)

USER = config.get('{}'.format(POSTGRES_SECTION), 'USER')
PASSWORD = config.get('{}'.format(POSTGRES_SECTION), 'PASSWORD')
HOST = config.get('{}'.format(POSTGRES_SECTION), 'HOST')
PORT =  config.get('{}'.format(POSTGRES_SECTION), 'PORT')
DATABASE =  config.get('{}'.format(POSTGRES_SECTION), 'DATABASE')
SCHEMA =  config.get('{}'.format(POSTGRES_SECTION), 'SCHEMA')
RESULT_TABLE_NAME =  config.get('{}'.format(POSTGRES_SECTION), 'RESULT_TABLE_NAME')
ERROR_DETAILS_TABLE =  config.get('{}'.format(POSTGRES_SECTION), 'ERROR_DETAILS_TABLE')

# Log file folder and log file name
LOG_FOLDER_NAME = config.get('{}'.format(LOGGING_SECTION), 'LOG_FOLDER_NAME')
LOG_FILE_NAME = config.get('{}'.format(LOGGING_SECTION), 'LOG_FILE_NAME')
LOG_WHEN = config.get('{}'.format(LOGGING_SECTION), 'LOG_WHEN')
LOG_INTERNAL = int(config.get('{}'.format(LOGGING_SECTION), 'LOG_INTERNAL'))
LOG_MAXBYTES = eval(config.get('{}'.format(LOGGING_SECTION), 'LOG_MAXBYTES'))
LOG_BACKUPCOUNT = int(config.get('{}'.format(LOGGING_SECTION), 'LOG_BACKUPCOUNT'))
LEVEL = eval(config.get('{}'.format(LOGGING_SECTION), 'LEVEL'))

DATABASEIP = eval(config.get('{}'.format(CASSANDRA_SECTION), 'DATABASEIP'))
KEYSPACE = config.get('{}'.format(CASSANDRA_SECTION), 'KEYSPACE')
CONFIG_KEYSPACE = config.get('{}'.format(CASSANDRA_SECTION), 'CONFIG_KEYSPACE')
TABLE_NAME = config.get('{}'.format(CASSANDRA_SECTION), 'TABLE_NAME')
CONFIG_TABLE_NAME = config.get('{}'.format(CASSANDRA_SECTION), 'CONFIG_TABLE_NAME')

ALGO_TAG=config.get('{}'.format('ALGO'), 'ALGO_TAG')
ALGORITHM_NAME=config.get('{}'.format('ALGO'), 'ALGORITHM_NAME')
CONSOLE_NAME = config.get('{}'.format('ALGO'), 'CONSOLE_NAME')

PERMISSION_FILE_CER = config.get('{}'.format('ALGO'), 'PERMISSION_FILE_CER')
PERMISSION_FILE_KEY = config.get('{}'.format('ALGO'), 'PERMISSION_FILE_KEY')

# Config file folder name and certificate file folder name
INPUT_FOLDER_NAME = config.get('{}'.format('ALGO'), 'INPUT_FOLDER_NAME')    # This will be removed once all configuration files are moved into DB
CONFIG_FOLDER_NAME = config.get('{}'.format('ALGO'), 'CONFIG_FOLDER_NAME')    # This will be removed once all configuration files are moved into DB
CERTIFICATE_FOLDER_NAME = config.get('{}'.format('ALGO'), 'CERTIFICATE_FOLDER_NAME')
CSV_FOLDER_NAME= config.get('{}'.format('ALGO'), 'CSV_FOLDER_NAME')

INPUT_DOL_FILE = config.get('{}'.format('ALGO'), 'INPUT_DOL_FILE')
BASIC_CONFIG_FILE = config.get('{}'.format('ALGO'), 'BASIC_CONFIG_FILE')
CONFIG_FILE = config.get('{}'.format('ALGO'), 'CONFIG_FILE')
ERROR_CODE_FILE = config.get('{}'.format('ALGO'), 'ERROR_CODE_FILE')
FURNACE_DOL_MAPPING_FILE = config.get('{}'.format('ALGO'), 'FURNACE_DOL_MAPPING_FILE')
GOOD_FURNACE_DATA_FILE = config.get('{}'.format('ALGO'), 'GOOD_FURNACE_DATA_FILE')
TAG_MIN_MAX_FILE = config.get('{}'.format('ALGO'), 'TAG_MIN_MAX_FILE')
TAG_LIST_FILE_NAME = config.get('{}'.format('ALGO'), 'TAG_LIST_FILE_NAME')
OUTPUT_TAG_DESCRIPTION_FILE_NAME = config.get('{}'.format('ALGO'), 'OUTPUT_TAG_DESCRIPTION_FILE_NAME')
CONCERN = config.get('{}'.format('ALGO'), 'CONCERN')
CONFIG_PARAMETERS_FILE = config.get('{}'.format('ALGO'), 'CONFIG_PARAMETERS_FILE')

'''
Below parameter specifies the scheduling interval of Furnace Feed Flo Drift Identification
algorithm.
Now it is scheduled to run this algorithm once in every 5 minutes
'''

# Alert Flag values
OFFLINE_FLAG = int(config.get('{}'.format('ALGO'), 'OFFLINE_FLAG'))   # This shows that particular furnace is offline

GREEN_FLAG = int(config.get('{}'.format('ALGO'), 'GREEN_FLAG'))
'''
When there is no predicted values for a predicted tag, alert flag is set with 
blue value
'''
BLUE_FLAG = int(config.get('{}'.format('ALGO'), 'BLUE_FLAG'))
YELLOW_FLAG = int(config.get('{}'.format('ALGO'), 'YELLOW_FLAG'))
RED_FLAG = int(config.get('{}'.format('ALGO'), 'RED_FLAG'))
MIN_ALERT = int(config.get('{}'.format('ALGO'), 'MIN_ALERT'))
MAX_ALERT = int(config.get('{}'.format('ALGO'), 'MAX_ALERT'))
ONE_DAY_EPOCH = int(config.get('{}'.format('ALGO'), 'ONE_DAY_EPOCH'))

'''
Files path
'''
LOG_FILE_PATH = '{}''{}''{}'.format(LOG_FOLDER_NAME,os.sep,LOG_FILE_NAME)
CERTFILE_FILE_PATH = '{}''{}''{}'.format(CERTIFICATE_FOLDER_NAME,os.sep,PERMISSION_FILE_CER)
KEYFILE_FILE_PATH = '{}''{}''{}'.format(CERTIFICATE_FOLDER_NAME,os.sep,PERMISSION_FILE_KEY)
INPUT_DOL_FILE_PATH = '{}''{}''{}'.format(INPUT_FOLDER_NAME,os.sep,INPUT_DOL_FILE)
BASIC_CONFIG_FILE_PATH = '{}''{}''{}''{}''{}'.format(CONFIG_FOLDER_NAME,os.sep,CSV_FOLDER_NAME,os.sep,BASIC_CONFIG_FILE)
CONFIG_FILE_PATH = '{}''{}''{}''{}''{}'.format(CONFIG_FOLDER_NAME,os.sep,CSV_FOLDER_NAME,os.sep,CONFIG_FILE)
ERROR_CODE_FILE_PATH = '{}''{}''{}''{}''{}'.format(CONFIG_FOLDER_NAME,os.sep,CSV_FOLDER_NAME,os.sep,ERROR_CODE_FILE)
FURNACE_DOL_MAPPING_FILE_PATH = '{}''{}''{}''{}''{}'.format(CONFIG_FOLDER_NAME,os.sep,CSV_FOLDER_NAME,os.sep,FURNACE_DOL_MAPPING_FILE)
GOOD_FURNACE_DATA_FILE_PATH = '{}''{}''{}''{}''{}'.format(CONFIG_FOLDER_NAME,os.sep,CSV_FOLDER_NAME,os.sep,GOOD_FURNACE_DATA_FILE)
TAG_MIN_MAX_FILE_PATH = '{}''{}''{}''{}''{}'.format(CONFIG_FOLDER_NAME,os.sep,CSV_FOLDER_NAME,os.sep,TAG_MIN_MAX_FILE)
TAG_LIST_FILE_PATH = '{}''{}''{}''{}''{}'.format(CONFIG_FOLDER_NAME,os.sep,CSV_FOLDER_NAME,os.sep,TAG_LIST_FILE_NAME)
OUTPUT_TAG_DESCRIPTION_FILE_PATH = '{}''{}''{}''{}''{}'.format(CONFIG_FOLDER_NAME,os.sep,CSV_FOLDER_NAME,os.sep,OUTPUT_TAG_DESCRIPTION_FILE_NAME)
CONFIG_PARAMETERS_FILE_PATH = '{}''{}''{}''{}''{}'.format(CONFIG_FOLDER_NAME,os.sep,CSV_FOLDER_NAME,os.sep,CONFIG_PARAMETERS_FILE)

# Loging file handler
logger = logging.getLogger()
logger.setLevel(LEVEL)
formatter = logging.Formatter(
    '%(asctime)s,%(levelname)s,%(filename)s,%(funcName)s,%(lineno)d,%(message)s')
handler = RotatingFileHandler(LOG_FILE_PATH, maxBytes=LOG_MAXBYTES, backupCount=LOG_BACKUPCOUNT)
handler.setFormatter(formatter)
logger.addHandler(handler)
