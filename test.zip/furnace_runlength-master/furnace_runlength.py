import pandas as pd
import numpy as np
import csv
import json
from scipy.stats import linregress
import os
import xml.etree.ElementTree as ET
import warnings
from itertools import islice
import sys, traceback, os
import time
from datetime import datetime, timedelta

from furnace_runlength_config import logger
from furnace_runlength_dbinterface import FurnaceRunlengthDBInterface

class FurnaceRunlength(object):

    def __init__(self):
        '''
        if not os.path.exists('logs'):
            os.makedirs('logs')

        self.logger = logging.getLogger()
        self.logger.setLevel(logging.INFO)
        formatter = logging.Formatter(
            '%(asctime)s,%(levelname)s,%(filename)s,%(funcName)s,%(lineno)d,%(message)s')
        handler = RotatingFileHandler('logs/FurnaceRunlength.log', maxBytes=10 * 1024 * 1024, backupCount=5)
        handler.setFormatter(formatter)
        self.logger.addHandler(handler)

        # end

        self.output_filename = 'Output/Output.csv'
        self.error_filename = 'Output/Error.csv'
        self.bad_input_tags_filename = "output/error/bad_input_tags.csv"
        self.limit_breach_filename = "output/error/limit_breach_tags.csv"
        self.offline_furnace_filename = "output/error/offline_furnace.csv"
        self.furnace_with_not_enough_data_filename = "output/error/furnace_with_not_enough_data.csv"
        '''
        # fetching the error code from error code list config

    def furnace_runlength_prediction(self,basic_config_df,config_df,error_code_df,furnace_dol_mapping_df,\
                                     good_furnace_data_df,tag_min_max_df,dol_df,tag_list_df,curr_time):
        """ This function is used for the Furnace Run length prediction by using the business logic and its condition
            to find the Actual A,B and R Square.
        """
        result_df=pd.DataFrame()
        error_details_df=pd.DataFrame()

        try:
            #LNS code changes start
            nan_code = error_code_df[error_code_df['Errors'].str.match('nan_data')].values[0][1]
            stuck_code = error_code_df[error_code_df['Errors'].str.match('stuck')].values[0][1]
            offline_code = error_code_df[error_code_df['Errors'].str.match('offline')].values[0][1]
            limit_breach_code = error_code_df[error_code_df['Errors'].str.match('limit_breach')].values[0][1]
            furnace_with_not_enough_data_code = \
                error_code_df[error_code_df['Errors'].str.match('furnace_with_not_enough_data')].values[0][1]

            logger.info("furnace_runlength_prediction start")
            s = time.time()
            #basic_config_df = pd.read_csv('config/csv/basic_conf.csv')


            logger.info("fetching all the required data from csv and storing in variables")
            #LNS code changes end

            # fetching all the required data from csv and storing in variables
            dol_value = float(basic_config_df['DOL_Value'])
            # cip_value = float(basic_config_df['CIP_Value'])
            conversion_value = float(basic_config_df['Conversion_Value'])
            feed_minimum = float(basic_config_df['Feed_Minimum'])
            feed_maximum = float(basic_config_df['Feed_Maximum'])
            shc_minimum = float(basic_config_df['SHC_Minimum'])
            shc_maximum = float(basic_config_df['SHC_Maximum'])
            minimum_r2 = float(basic_config_df['Minimum_R2'])
            moving_average = int(basic_config_df['Moving_Average'])

            # reading the dol file to check which furnace dol is greater than specified dol

            #dol_df = pd.read_csv('input/dol.csv')
            # reading furnace dol mapping file
            #furnace_dol_mapping_df = pd.read_csv('config/csv/furnace_dol_mapping.csv')
            offline_furnace_df = dol_df
            furnace_with_below_dol = dol_df
            dol_df_date = dol_df['TimeStamp'].values[0]
            dol_df = dol_df.drop(['TimeStamp'], axis=1)
            furnace_with_below_dol = furnace_with_below_dol.drop(['TimeStamp'], axis=1)
            dol_df = dol_df.drop(dol_df.columns[dol_df.apply(lambda col: not col.values[0] > dol_value)], axis=1)
            offline_furnace_df = offline_furnace_df.drop(
                offline_furnace_df.columns[offline_furnace_df.apply(lambda col: not col.values[0] == 0)], axis=1)
            furnace_with_below_dol = furnace_with_below_dol.drop(
                furnace_with_below_dol.columns[furnace_with_below_dol.apply(lambda col: col.values[0] > dol_value)],
                axis=1)
            dol_df = dol_df.T.reset_index()
            dol_df.columns = ['Furnace', 'DOL_Value']
            datetime_list = []
            current_datetime = datetime.now()
            for each_index, each_row in dol_df.iterrows():
                start_date = str(current_datetime - timedelta(days=each_row['DOL_Value']))
                datetime_list.append(start_date)

            dol_df['Start_Date'] = datetime_list
            dol_df['End_Date'] = current_datetime
            # end_date = current_datetime
            dol_df.insert(0, 'TimeStamp', dol_df_date)
            dol_df.DOL_Value = dol_df.DOL_Value.astype(int)
            furnace_list_for_calculation = \
                furnace_dol_mapping_df.loc[furnace_dol_mapping_df['DOL'].isin(dol_df['Furnace'].values)][
                    'Furnace'].values
            dol_df = dol_df.replace(dol_df['Furnace'].values, furnace_list_for_calculation, inplace=False)
            # dol_df.to_csv('required_days_data.csv', index=False)
            # output of DOl
            '''
            if not dol_df.empty:
                dol_df.to_csv('output/required_days_data.csv', index=0)
            else:
                if os.path.exists('output/required_days_data.csv'):
                    os.remove('output/required_days_data.csv')
            '''

            #LNS code start
            db_obj= FurnaceRunlengthDBInterface()
            logger.info("input_data fetch time start:{}".format(datetime.now()))
            input_data_df = db_obj.readInputDataFromDB(dol_df,tag_list_df,curr_time)
            #input_data_df.to_csv("input_data.csv",index=False)
            logger.info("input_data fetch time end:{}".format(datetime.now()))
            if input_data_df.empty:
                logger.error("input data is empty, algorithm could not be proceeded")
                return
            #LNS code end

            # reading the config file
            #config_df = pd.read_csv('config/csv/config.csv')
            config_df = config_df.loc[config_df['Furnace'].isin(furnace_list_for_calculation)]
            # df.columns = map(str.upper, df.columns)

            # check for nan data and limit breach tag and offline furnace
            #tag_min_max_df = pd.read_csv('config/csv/tag_min_max.csv')
            list_of_bad_input_tag_non_numeric = []
            faulty_furnace_list = []
            limit_breach_tag = []
            offline_furnace_list = []
            fdhdr_list = furnace_dol_mapping_df['FDHDR'].values

            dict_of_all_index_to_be_removed = {}
            for config_df_index, config_df_row in config_df.iterrows():
                temp_df = input_data_df
                column_list = []
                # creating a column list need to fetch from the input data
                furnace_name = config_df_row['Furnace']
                coil_number = config_df_row['Coil']
                hamhdr_name = config_df_row['FDHDR']
                hamhdr_actual_value = temp_df[hamhdr_name].tail().values[0]
                dol_name_for_current_furnace = \
                    str(furnace_dol_mapping_df[furnace_dol_mapping_df['Furnace'].str.match(furnace_name)][
                            'Furnace'].values[
                            0])

                dol_value_for_current_furnace = int(
                    dol_df.loc[dol_df['Furnace'] == dol_name_for_current_furnace]['DOL_Value'])

                column_list.append('TimeStamp')
                column_list.append(config_df_row['DOL'])
                column_list.append(config_df_row['Feed'])
                if hamhdr_actual_value == 2:
                    column_list.append(config_df_row['Conversion_Butane'])
                elif hamhdr_actual_value == 3:
                    column_list.append(config_df_row['Conversion_Ethane'])
                elif hamhdr_actual_value == 5:
                    column_list.append(config_df_row['Conversion_Propane'])
                column_list.append(config_df_row['SHC'])
                column_list.append(config_df_row['CIP'])
                column_list.append(config_df_row['FDHDR'])
                temp_df = temp_df[column_list]
                dataset = temp_df
                dataset = dataset.tail(dol_value_for_current_furnace)

                # identifying the nan value in the data set
                logger.info("identifying the nan value in the data set")

                input_data_error_handling_df = dataset.apply(pd.to_numeric, errors='coerce')
                del input_data_error_handling_df['TimeStamp']
                list_of_all_index_to_be_removed = []

                for key, value in input_data_error_handling_df.iteritems():
                    if np.isnan(value.values).any():
                        list_of_index_nan_data = np.argwhere(np.isnan(value.values))
                        list_of_index_nan_data = list(np.ravel(list_of_index_nan_data))
                        list_of_all_index_to_be_removed.extend(list_of_index_nan_data)
                        if len(value.values) - 1 in list_of_index_nan_data:
                            list_of_bad_input_tag_non_numeric.append(key)
                        faulty_furnace_list.append(furnace_name)
                    else:
                        if key not in fdhdr_list:
                            min_value = tag_min_max_df[tag_min_max_df['Tags'].str.match(key)]['Min'].values[0]
                            max_value = tag_min_max_df[tag_min_max_df['Tags'].str.match(key)]['Max'].values[0]

                            limit_breach_tag_value = [x for x in list(value.values) if not min_value < x < max_value]
                            if limit_breach_tag_value:
                                list_of_index_limit_breach = [i for i, e in enumerate(list(value.values)) if
                                                              e in limit_breach_tag_value]
                                list_of_all_index_to_be_removed.extend(list_of_index_limit_breach)
                                if len(value.values) - 1 in list_of_index_limit_breach:
                                    limit_breach_tag.append(key)
                                faulty_furnace_list.append(furnace_name)

                        if key in fdhdr_list:
                            offline_furnace_value = [x for x in list(value.values) if x not in [2, 3, 5]]
                            if offline_furnace_value:
                                list_of_index_offline_furnace = [i for i, e in enumerate(list(value.values)) if
                                                          e in offline_furnace_value]
                                list_of_all_index_to_be_removed.extend(list_of_index_offline_furnace)
                                if len(value.values) - 1 in list_of_index_offline_furnace:
                                    offline_furnace_list.append(furnace_name)
                if list_of_all_index_to_be_removed:
                    if furnace_name not in dict_of_all_index_to_be_removed:
                        dict_of_all_index_to_be_removed[furnace_name] = {coil_number: list_of_all_index_to_be_removed}
                    else:
                        dict_of_all_index_to_be_removed.get(furnace_name)[coil_number] = list_of_all_index_to_be_removed

            matched_furnace_list = \
                furnace_dol_mapping_df.loc[furnace_dol_mapping_df['DOL'].isin(offline_furnace_df.columns.values)][
                    'Furnace'].values

            matched_furnace_list_with_less_dol = \
                furnace_dol_mapping_df.loc[furnace_dol_mapping_df['DOL'].isin(furnace_with_below_dol.columns.values)][
                    'Furnace'].values
            offline_furnace_list.extend(matched_furnace_list)
            offline_furnace_list = list(set(offline_furnace_list))

            # removing furnace from config file to skip the calculation
            furnace_list_for_calculation_new = [x for x in furnace_list_for_calculation if
                                                x not in offline_furnace_list]

            config_df = config_df.loc[config_df['Furnace'].isin(furnace_list_for_calculation_new)]


            # loop for config file to iter every coil
            store_dataset = pd.DataFrame()
            file_index = 0
            furnace_with_not_enough_data = []
            furnace_dict_with_not_enough_data = {}
            for config_df_index, config_df_row in config_df.iterrows():
                temp_df = input_data_df
                column_list = []
                # creating a column list need to fetch from the input data
                furnace_name = config_df_row['Furnace']
                coil_number = config_df_row['Coil']
                hamhdr_name = config_df_row['FDHDR']
                dol_name_for_current_furnace = \
                    str(furnace_dol_mapping_df[furnace_dol_mapping_df['Furnace'].str.match(furnace_name)][
                            'Furnace'].values[
                            0])

                dol_value_for_current_furnace = int(
                    dol_df.loc[dol_df['Furnace'] == dol_name_for_current_furnace]['DOL_Value'])

                dataset = temp_df.tail(dol_value_for_current_furnace)

                dataset = dataset.reset_index(drop=True)
                if dict_of_all_index_to_be_removed.get(furnace_name):
                    if dict_of_all_index_to_be_removed.get(furnace_name).get(coil_number):
                        index_to_be_removed = dict_of_all_index_to_be_removed.get(furnace_name).get(coil_number)
                        dataset = dataset.drop(index_to_be_removed)
                        dataset = dataset.reset_index(drop=True)
                        if dataset.shape[0] < dol_value:
                            furnace_with_not_enough_data.append(furnace_name)
                            if furnace_name not in furnace_dict_with_not_enough_data:
                                furnace_dict_with_not_enough_data[furnace_name] = [coil_number]
                            else:
                                furnace_dict_with_not_enough_data[furnace_name] = furnace_dict_with_not_enough_data.get(
                                    furnace_name) + [coil_number]
                            continue

                hamhdr_actual_value = dataset[hamhdr_name].tail(1).values[0]
                column_list.append('TimeStamp')
                column_list.append(config_df_row['DOL'])
                column_list.append(config_df_row['Feed'])
                if hamhdr_actual_value == 2:
                    column_list.append(config_df_row['Conversion_Butane'])
                elif hamhdr_actual_value == 3:
                    column_list.append(config_df_row['Conversion_Ethane'])
                elif hamhdr_actual_value == 5:
                    column_list.append(config_df_row['Conversion_Propane'])
                column_list.append(config_df_row['SHC'])
                column_list.append(config_df_row['CIP'])
                column_list.append(config_df_row['FDHDR'])
                dataset = dataset[column_list]
                dataset.columns = ['TimeStamp', 'DOL', 'Feed', 'Conversion', 'SHC', 'CIP', 'FDHDR']

                if hamhdr_actual_value == 2:
                    dataset['Conversion'] = dataset['Conversion'] * 22.9417 + 66.5841

                # creating variables
                logger.info("creating variables")
                y_list = []
                y_filter = []
                y_filter_df = pd.DataFrame()
                y_df = pd.DataFrame()
                logger.info("fetching the feed shc conversion and cip values of calculation of y")
                for index in range(dataset.shape[0]):
                    # fetching the feed shc conversion and cip values of calculation of y
                    feed = float(dataset.iloc[index].values[2])
                    conversion = float(dataset.iloc[index].values[3])
                    shc = float(dataset.iloc[index].values[4])
                    cip = float(dataset.iloc[index].values[5])
                    # formula for calculating y
                    y = (feed * conversion / 100 + shc) / cip

                    y_list.append(y)
                    # condtion for filtering y which value of y need to be consider

                    if (feed_minimum < feed < feed_maximum) and (conversion > conversion_value) and (
                            shc_minimum <= shc <= shc_maximum):
                        y_filter.append(y)
                    else:
                        y_filter.append(y)
                y_df['Y'] = y_list
                y_filter_df['YFILTER'] = y_filter

                y_and_yfilter_df = pd.concat([y_df, y_filter_df], axis=1)

                # new dataset
                dataset = pd.concat([dataset, y_and_yfilter_df], axis=1, ignore_index=False)

                counter = 0
                index_for_slicing = []

                for index, row in dataset.iterrows():
                    if index >= moving_average - 1:
                        if not index_for_slicing:
                            index_for_slicing.append(index)
                        temp_avg = np.average(
                            dataset[counter:index + 1]['YFILTER'].dropna().values)
                        dataset.at[index, 'MA'] = temp_avg
                        dataset.at[index, 'LN'] = np.log(temp_avg)
                        dataset.at[index, 'X'] = row['DOL']
                        # calculating slope intercept and r square value
                        if index_for_slicing[0] != index:
                            slope, intercept, r_value, p_value, std_err = linregress(
                                dataset[index_for_slicing[0]:index + 1]['X'].dropna(),
                                dataset[index_for_slicing[0]:index + 1]['LN'].dropna())
                            dataset.at[index, 'INTERCEPT'] = intercept
                            dataset.at[index, 'CALC-A'] = np.exp(intercept)
                            dataset.at[index, 'CALC-B'] = slope
                            dataset.at[index, 'CALC-R2'] = r_value ** 2
                        counter += 1
                logger.info("sorting the column MA by dsc and getting top 5 values")

                # sorting the column MA by dsc and getting top 5 values
                ma_df_dsc = dataset.sort_values(by='MA', ascending=False)

                dsc_sort_ma_top_5_df = pd.DataFrame(ma_df_dsc['MA'].head().dropna())
                dsc_sort_ma_top_5 = dsc_sort_ma_top_5_df.values
                logger.info("fetching the index of the top 5 value")
                # fetching the index of the top 5 value

                dsc_sort_ma_top_5_index = dsc_sort_ma_top_5_df.index.values
                current_b = []
                dataset_ma = pd.DataFrame()
                dataset_ma_index = 0
                last_index_of_dataset = dataset.index.values[-1:][0]
                y_max = np.max(dataset['Y'].values)
                logger.info("calculation for MA-A MA-B MA-R2")
                # calculation for MA-A MA-B MA-R2
                for index in dsc_sort_ma_top_5_index:

                    y = dataset[index:]['LN'].dropna()
                    x = dataset[index:]['X'].dropna()

                    ma_slope, ma_intercept, ma_r_value, ma_p_value, ma_std_err = linregress(x, y)
                    dataset_ma.at[dataset_ma_index, 'MA'] = dsc_sort_ma_top_5[dataset_ma_index]
                    dataset_ma.at[dataset_ma_index, 'MA-A'] = np.exp(ma_intercept)
                    dataset_ma.at[dataset_ma_index, 'MA-B'] = ma_slope
                    dataset_ma.at[dataset_ma_index, 'MA-R2'] = ma_r_value ** 2
                    dataset_ma_index += 1

                    # condition for finding out the r square value greater than 0.75 from the dsc sorted data
                    if not current_b and ma_r_value ** 2 > minimum_r2:
                        current_b.append(ma_slope)
                        dataset.at[last_index_of_dataset, 'MA-A'] = np.exp(ma_intercept)
                        dataset.at[last_index_of_dataset, 'MA-B'] = ma_slope
                        dataset.at[last_index_of_dataset, 'MA-R2'] = ma_r_value ** 2

                    # fetching the GOOD A B and R square value
                    #good_furnace_data_df = pd.read_csv('config/csv/good_furnace_data.csv')
                    matched_good_furnace_data_df = pd.DataFrame(good_furnace_data_df[
                                                                    (good_furnace_data_df[
                                                                         'Furnace'] == furnace_name) & (
                                                                            good_furnace_data_df[
                                                                                'Coil'] == coil_number) & (
                                                                            good_furnace_data_df[
                                                                                'FDHDR'] == hamhdr_actual_value)])

                    dataset.at[last_index_of_dataset, 'GOOD-A'] = matched_good_furnace_data_df['A'].values[0]
                    dataset.at[last_index_of_dataset, 'GOOD-B'] = matched_good_furnace_data_df['B'].values[0]
                    dataset.at[last_index_of_dataset, 'GOOD-R2'] = matched_good_furnace_data_df['R2'].values[0]
                    dataset.at[last_index_of_dataset, 'YMAX'] = y_max
                logger.info("fetching the dataset of current data time")
                # fetching the dataset of current data time
                current_dataset = dataset.tail(1)
                logger.info("condition for calculation A B and R square")
                # condition for calculation A B and R square
                logger.info("calculation for A")

                # calculation for A
                if current_dataset['DOL'].values[0] < dol_value or not (
                        isinstance(current_dataset['CALC-A'].values[0], int) or isinstance(
                    current_dataset['CALC-A'].values[0],
                    float)) or \
                        not (isinstance(current_dataset['CALC-B'].values[0], int) or isinstance(
                            current_dataset['CALC-B'].values[0],
                            float)) or \
                        current_dataset['CALC-R2'].values[0] < minimum_r2 or current_dataset['CALC-B'].values[0] > 0:
                    actual_a = y_max


                else:
                    actual_a = current_dataset['CALC-A'].values[0]

                logger.info("calculation for B and R square")
                # calculation for B and R square
                if current_dataset['CALC-B'].values[0] > 0 or current_dataset['DOL'].values[0] < dol_value:
                    actual_b = current_dataset['GOOD-B'].values[0]
                    actual_r_square = current_dataset['GOOD-R2'].values[0]

                elif current_dataset['DOL'].values[0] < dol_value or not (
                        isinstance(current_dataset['CALC-A'].values[0], int) or isinstance(
                    current_dataset['CALC-A'].values[0],
                    float)) or \
                        not (isinstance(current_dataset['CALC-B'].values[0], int) or isinstance(
                            current_dataset['CALC-B'].values[0],
                            float)) or \
                        current_dataset['CALC-R2'].values[0] < minimum_r2:
                    if 'MA-B' in current_dataset.columns:
                        actual_b = current_dataset['MA-B'].values[0]
                        actual_r_square = current_dataset['MA-R2'].values[0]

                    else:
                        actual_b = current_dataset['GOOD-B'].values[0]
                        actual_r_square = current_dataset['GOOD-R2'].values[0]

                else:
                    actual_b = current_dataset['CALC-B'].values[0]
                    actual_r_square = current_dataset['CALC-R2'].values[0]
                logger.info("fetching the feed conversion and cip value from the current dataset")

                # if the actual b is positive then replace with good b
                if actual_b > 0:
                    actual_b = current_dataset['GOOD-B'].values[0]

                # fetching the feed conversion shc and cip value from the current dataset
                current_feed = float(current_dataset.iloc[0].values[2])
                current_conversion = float(current_dataset.iloc[0].values[3])
                current_shc = float(current_dataset.iloc[0].values[4])
                current_cip = float(current_dataset.iloc[0].values[5])

                logger.info("calculation for  the value of y when the cip value is 50 which is configurable")

                # calculation for  the value of y when the cip value is 50 which is configurable
                # reading cip value from csv configuration

                cip_value = basic_config_df[furnace_name + '_CIP'].values[0]
                current_y = (current_feed * current_conversion / 100 + current_shc) / cip_value
                logger.info("calculation for the value of time")
                # print("Current Y",current_y)
                # calculation for the value of time
                current_time = np.log(current_y / actual_a) / actual_b
                # calculating y_cip
                y_cip = actual_a * np.exp(actual_b * current_dataset['DOL'].values[0])
                cip_predict = (current_feed * current_conversion / 100 + current_shc) / y_cip
                # print("Current Time",current_time)

                store_dataset.at[file_index, 'TimeStamp'] = current_dataset['TimeStamp'].values[0]
                store_dataset.at[file_index, 'FDHDR'] = current_dataset['FDHDR'].values[0]
                store_dataset.at[file_index, 'Furnace'] = furnace_name
                store_dataset.at[file_index, 'Coil'] = coil_number
                store_dataset.at[file_index, 'DOL'] = current_dataset['DOL'].values[0]
                store_dataset.at[file_index, 'FEED'] = current_feed
                store_dataset.at[file_index, 'CONVERSION'] = current_conversion
                store_dataset.at[file_index, 'SHC'] = current_shc
                store_dataset.at[file_index, 'CIP'] = current_cip
                store_dataset.at[file_index, 'CALC-A'] = np.exp(intercept)
                store_dataset.at[file_index, 'CALC-B'] = slope
                store_dataset.at[file_index, 'CALC-R2'] = r_value ** 2
                store_dataset.at[file_index, 'A'] = actual_a
                store_dataset.at[file_index, 'B'] = actual_b
                store_dataset.at[file_index, 'R2'] = actual_r_square
                store_dataset.at[file_index, 'Y'] = current_y
                store_dataset.at[file_index, 'CIP_PREDICT'] = cip_predict
                store_dataset.at[file_index, 'TIME'] = current_time
                file_index += 1
            if not store_dataset.empty:
                store_dataset['positive_runlength_with_r2'] = np.where(
                    (store_dataset['TIME'] > 100) & (store_dataset['CALC-R2'] < minimum_r2),
                    100, store_dataset['TIME'])

                furnace_list = furnace_dol_mapping_df['Furnace'].values
                # finding min runlength of all coil from every furnace
                for i in furnace_list:
                    matched_furnace_df = store_dataset[store_dataset['Furnace'].str.match(i)]
                    if not matched_furnace_df.empty:
                        actual_time_list_for_min = matched_furnace_df['positive_runlength_with_r2'].values
                        actual_time_list_for_min = [i for i in actual_time_list_for_min if i > 0]
                        min_runlength = np.min(actual_time_list_for_min)
                        store_dataset.at[matched_furnace_df.index.values, 'Furnace Runlength'] = min_runlength
                store_dataset = store_dataset.drop(['positive_runlength_with_r2'], axis=1)

            #LNS code start
            result_df=store_dataset[['TimeStamp','FDHDR','Furnace','Coil','DOL','TIME','Furnace Runlength']]
            '''
            if not store_dataset.empty:
                with open('output/runlength_temp_data.csv', 'w', newline='') as f:
                    store_dataset.to_csv(f, index=None, header=True)
            else:
                if os.path.exists('output/runlength_temp_data.csv'):
                    os.remove('output/runlength_temp_data.csv')
            '''
            data_list=[]
            error_details_list=[]
            # creating dict for furnace which is not used for calculation
            furnace_dict_with_not_enough_data_1 = {i: [] for i in matched_furnace_list_with_less_dol}
            furnace_dict_with_not_enough_data.update(furnace_dict_with_not_enough_data_1)
            # creating csv for furnace_dict_with_not_enough_data

            if furnace_dict_with_not_enough_data:

                '''
                logger.info("creating csv for furnace_dict_with_not_enough_data")
                furnace_with_not_enough_data_filename_writer = csv.writer(
                    open(furnace_with_not_enough_data_filename, "w", newline='', ))
                furnace_with_not_enough_data_filename_writer.writerow(['Furnace', 'Coil', 'Error Code'])
                '''
                for key, value in furnace_dict_with_not_enough_data.items():
                    if value:
                        for each_coil in value:
                            data_list=(key,each_coil,furnace_with_not_enough_data_code)
                            error_details_list.append(data_list)

                    else:
                        data_list = (key,key, furnace_with_not_enough_data_code)
                        error_details_list.append(data_list)
                '''
            else:
                if os.path.exists(self.furnace_with_not_enough_data_filename):
                    os.remove(self.furnace_with_not_enough_data_filename)
                '''
            list_of_bad_input_tag_non_numeric = list(set(list_of_bad_input_tag_non_numeric))
            # creating csv for bad input
            if list_of_bad_input_tag_non_numeric:
                for each_tag in list_of_bad_input_tag_non_numeric:
                    data_list=(each_tag,each_tag, nan_code)
                    error_details_list.append(data_list)
            '''
                logger.info("creating csv for bad input")
                bad_input_tags_filename_writer = csv.writer(open(self.bad_input_tags_filename, "w", newline='', ))
                bad_input_tags_filename_writer.writerow(['Tags', 'Error Code'])
                for each_tag in list_of_bad_input_tag_non_numeric:
                    bad_input_tags_filename_writer.writerow([each_tag, self.nan_code])
            else:
                if os.path.exists(self.bad_input_tags_filename):
                    os.remove(self.bad_input_tags_filename)
            '''
            # creating csv for limit breach tag
            limit_breach_tag = list(set(limit_breach_tag))
            logger.info("creating csv for limit breach ")

            if limit_breach_tag:
                for each_tag in limit_breach_tag:
                    data_list=(each_tag,each_tag, limit_breach_code)
                    error_details_list.append(data_list)
                '''
                limit_breach_filename_writer = csv.writer(open(self.limit_breach_filename, "w", newline='', ))
                limit_breach_filename_writer.writerow(['Tags', 'Error Code'])
                for each_tag in limit_breach_tag:
                    limit_breach_filename_writer.writerow([each_tag, self.limit_breach_code])
            else:
                if os.path.exists(self.limit_breach_filename):
                    os.remove(self.limit_breach_filename)
                '''
            # creating csv for offline furnace
            if offline_furnace_list:
                logger.info("creating csv for offline furnace")
                for each_furnace in offline_furnace_list:
                    data_list = (each_furnace, each_furnace, offline_code)
                    error_details_list.append(data_list)
                '''
                offline_furnace_filename_writer = csv.writer(open(self.offline_furnace_filename, "w", newline='', ))
                offline_furnace_filename_writer.writerow(['Furnace', 'Error Code'])
                for each_furnace in offline_furnace_list:
                    offline_furnace_filename_writer.writerow([each_furnace, self.offline_code])
            else:
                if os.path.exists(self.offline_furnace_filename):
                    os.remove(self.offline_furnace_filename)
                '''
            #print("time taken", time.time() - s)
            error_details_df=pd.DataFrame(error_details_list,columns=['furnace','tags','error_code'])

            logger.info("furnace_runlength_prediction end")
            return result_df,error_details_df
            #LNS code changes END


        except Exception as e:

            if hasattr(e, 'message'):

                logger.error("Exception raised %s", e.message)

            else:

                logger.error("Exception raised %s", type(e).__name__)

            exc_type, exc_obj, exc_tb = sys.exc_info()

            logger.exception("something went wrong with exception")

            logger.error("something went wrong with exception on line %s", exc_tb.tb_lineno)
            #print("something went wrong with exception on line %s", exc_tb.tb_lineno,e)

            traceback.print_exc(file=sys.stdout)

            return result_df,error_details_df

#LNS code changes start
#furnace_runlength_obj = FurnaceRunlength()
#furnace_runlength_obj.furnace_runlength_prediction()
#LNS code changes end