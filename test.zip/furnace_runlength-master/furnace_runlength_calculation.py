"""
File                : furnace_runlength_calculation.py

Description         : This file contains furnace runlength calculation Class.


Author              : LNS Team

Date Created        : 27-Nov-2019

Date Last modified  :

Copyright (C) 2019 LivNSense Technologies - All Rights Reserved

"""

from datetime import datetime,timedelta
import time as t
import pandas as pd

from furnace_runlength_dbinterface import FurnaceRunlengthDBInterface
from furnace_runlength import FurnaceRunlength

from furnace_runlength_config import logger,CONFIG_PARAMETERS_FILE_PATH
from furnace_runlength_config import CONSOLE_NAME,ALGO_TAG,GREEN_FLAG,YELLOW_FLAG,RED_FLAG,MIN_ALERT,MAX_ALERT,CONCERN

class FurnaceRunlengthCalculation(object):
    def handle_furnacerunlength_result(self, result_df,db_obj,output_tag_description_df,timestamp):
        '''
        This method is used to handle the result of Furnace Runlength Algorithm's Result for All furnaces

        :param result_df: Holds the result data
        :param db_obj: furnace runlength class object
        :param output_tag_description_df: contains description for the output tags
        :param timestamp: timestamp at which input is fetched
        :return: None
        '''

        try:
            result_data = []

            if not result_df.empty:
                # result_df.columns = ['furnace','coil','tags','error_code']
                result_df=pd.merge(result_df,output_tag_description_df,on=['Furnace','Coil'], how='left')
                result_df=result_df.drop('Furnace',axis=1)
                for indx, row in result_df.iterrows():
                    '''
                    Each row contains ['TimeStamp','FDHDR','Furnace','Coil','DOL','TIME','Furnace Runlength'] alert flag details for all furnaces

                    Construct the result as
                    [console_name, equipment_tag, tag_name, actual_value,predicted_value,\
                    alert_flag,description,unit,timestamp]                    
                    '''
                    if row['TIME']<MIN_ALERT:
                        coil_alert_flag= RED_FLAG
                    elif row['TIME']<MAX_ALERT and row['TIME']>=MIN_ALERT:
                        coil_alert_flag=YELLOW_FLAG
                    else :
                        coil_alert_flag=GREEN_FLAG

                    if row['Furnace Runlength']<MIN_ALERT:
                        alert_flag= RED_FLAG
                    elif row['Furnace Runlength']<MAX_ALERT and row['Furnace Runlength']>=MIN_ALERT:
                        alert_flag=YELLOW_FLAG
                    else :
                        alert_flag=GREEN_FLAG


                    data_list = (CONSOLE_NAME ,row['equipment_tag'] ,row['Coil'], row['DOL'], row['Furnace Runlength'],
                                 row['TIME'], row['description'],timestamp,ALGO_TAG,alert_flag,coil_alert_flag,CONCERN)

                    result_data.append(data_list)
            if result_data:
                db_obj.updateResultDataIntoDB(result_data)

            else:
                logger.debug("There is no Result data to update into DB : Furnace \
                                 Runlength Algorithm")



        except Exception as ex:

            logger.error("Error Occurred while handling Furnace \
                                 Runlength Algorithm result  : " + str(ex))

    def handle_furnace_runlength_error_result(self, error_details, db_obj, timestamp):

        '''
        This method is used to handle the error details that occurred in
        Furnace Runlength Algorithm

        Input Parameters:
            1. error_details  :  Holds the error details  data
            2. db_obj     :  Specifies the DB interface class object
            3. timestamp  :  Holds timestamp value
        Returns : None
        '''
        try:
            error_result = []
            for indx, row in error_details.iterrows():
                '''
                each row contains [ furnace name, module error, Error Code]
                Construct the error result as
                [console_name, equipment_tag(furnace_name),algo_tag, tag_name(module),error_code,timestamp]
                '''
                error_result.append((CONSOLE_NAME, row[0], ALGO_TAG, row[1], row[2], timestamp))

            db_obj.updateErrorDetailsIntoDB(error_result)

        except Exception as ex:

            logger.error("Error Occurred while handling Furnace Runlength Algorithms's error result  : " + str(ex))
    def handle_furnace_runlength_module(self,db_obj):
        '''
        Starting point of this algorithm
        '''
        try:
            '''
            Read configuration parameters for all equipments
            '''
            basic_config_df,config_df, error_code_df, furnace_dol_mapping_df,\
                    good_furnace_data_df, tag_min_max_df,tag_list_df,output_tag_description_df = db_obj.readConfigParametersFromDB()
            if basic_config_df.empty or config_df.empty or error_code_df.empty or furnace_dol_mapping_df.empty \
                    or good_furnace_data_df.empty or tag_min_max_df.empty or tag_list_df.empty or output_tag_description_df.empty:
                '''
                Configuration parameters empty
                '''
                logger.error("Configuration Parameter Data frame is empty, Could not proceed further operations ")
                return
            #utc_datetime = datetime.utcnow()
            curr_time = t.time()
            curr_time = int((curr_time - (
                        curr_time % 60) - 120) * 1000)  # some tags updating with the delay of 2 minutes hence 120 need to be subracted
            #timestamp= pd.to_datetime(curr_time,unit='ms')
            #timestamp = utc_datetime.strftime("%Y-%m-%d %H:%M:%S")
            input_dol_df=db_obj.readDolInputFromDB(curr_time)

            if input_dol_df.empty:
                '''
                Input_data2_df can be empty at very first iteration of this algorithm
                '''
                logger.error("Input dol data is empty, could not proceed further ")
                return

            '''
            Call Furnace Runlength Calculation Method, below method is defined in Ingenero team files
            '''
            furnace_runlength_obj=FurnaceRunlength()
            result_df, error_details_df = furnace_runlength_obj.\
                furnace_runlength_prediction(basic_config_df, config_df, error_code_df, furnace_dol_mapping_df,
                                             good_furnace_data_df, tag_min_max_df,input_dol_df,tag_list_df,curr_time)
            # Get Furnace Mapping Table
            time_stamp=input_dol_df['TimeStamp'][0]
            if not result_df.empty:
                self.handle_furnacerunlength_result(result_df,db_obj,output_tag_description_df,time_stamp)
            else:
                logger.error("Result data not predicted")
            if not error_details_df.empty:
                self.handle_furnace_runlength_error_result(error_details_df,db_obj,time_stamp)
            else:
                logger.error("No error details to update the error table")
            #logger.info("Furnace Runlength Algorithms results and error details are updated into DB ")

        except Exception as ex:

            logger.error("Error occurred while handling Furnace Runlength method : " + str(ex))

def furnace_runlength_module():
    '''
    Starting function of this algorithm
    '''
    '''
    Get Input Data set from DB
    '''

    db_obj = FurnaceRunlengthDBInterface()
    db_obj.config_check()

    config_df = pd.read_csv(CONFIG_PARAMETERS_FILE_PATH, index_col="Parameter")

    deactive_flag = config_df.loc['active_deactive', 'Value']
    # If this flag value is 1, the algorithm i sactive and should aloow to run
    # if this flag value is zero, the algorithm is deactive and should not aloow to proceed further
    if not deactive_flag:
        logger.info("The Furnace Feed Flow algorithm is deactivated.....")
        return
    furnace_runlength_obj = FurnaceRunlengthCalculation()

    furnace_runlength_obj.handle_furnace_runlength_module(db_obj)
